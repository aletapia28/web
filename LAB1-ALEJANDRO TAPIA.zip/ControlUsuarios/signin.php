<?php

    IniciarSesion();

    function IniciarSesion(){
        include 'controller.php';

        $user= $_GET["correoUser"];
        $password= $_GET["password"];

        $controller = new controller;

        if($controller->validarCredenciales($user,$password))
        {
            header('Location: index.php');   }
        else{   
            echo '<script>alert("El usuario o password esta incorrecto");
            history.back();</script>';


        }



    }




?>