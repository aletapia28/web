
<?php

include 'controller.php';
$controller = new controller;

if ($controller->UpdatePass()) {
    echo '<script language="javascript">alert("Cambio Exitoso");</script>';
} else
    echo '<script language="javascript">alert("Ocurrio un error");
    history.back();</script>';








?>