<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="utf-8">
    <title>Registrarse</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="login.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <script type="text/javascript" src="login.js"></script>
</head>

<body>
    <div class="barra">
        <button class=" btn btn-login cambio-pag " type="submit" onclick="location.href='login.php'">Iniciar
            Sesion</button>

    </div>
    <div class="text-center register-container card">
        <div class="form-register">
            <h1>Bienvenido</h1>
            <form action="usuario.php" method="get">
                <div class="form-register">

                    <input class="input" type="text" id="Nombre" placeholder="Nombre" name="name" required autofocus>
                    <input class="input" type="text" id="Apellido1" placeholder="Primer apellido" name="apellido1" required autofocus>
                    <input class="input" type="text" id="Apellido2" placeholder="Segundo apellido" name="apellido2" required autofocus>
                    <input class="input" type="number" id="identificacion" placeholder="Identificación" name="identificacion" required autofocus>
                    <input class="input" type="Correo" id="correo" placeholder="Correo" name="correo" required autofocus>
                    <input class="input" type="password" id="password" placeholder="Contraseña" name="password" required autofocus title="Debe contener numeros, mayúsculas y mininúsculas. Minimo 8 dígitos">
                    <input class="input" type="tel" id="telefono" placeholder="Número de teléfono" name="telefono" required autofocus>
                    <input class="input" type="date" id="fecha" placeholder="Fecha de nacimiento" name="fecha" required autofocus>
                </div>
                <div>
                    <input class=" btn btn-login " type="submit" value= "Registrarse"></button>
                </div>
            </form>




        </div>
    </div>

</body>