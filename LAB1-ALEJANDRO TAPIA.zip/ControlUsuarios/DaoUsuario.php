<?php
class usuario{
    private $nombre='';
    private $Apellido1='';
    private $Apellido2='';
    private $Identificacion='';
    private $correo='';
    private $contrasena='';
    private $telefono='';
    private $Nacimiento='';




    public function __construct($nombre,$Apellido1,$Apellido2,$Identificacion,$correo,$contrasena,$telefono,$Nacimiento)
    {
        $this->nombre=$nombre;
        $this->Apellido1=$Apellido1;
        $this->Apellido2=$Apellido2;
        $this->Identificacion=$Identificacion;
        $this->correo=$correo;
        $this->contrasena=$contrasena;
        $this->telefono=$telefono;
        $this->Nacimiento=$Nacimiento;

    }

    
}
?>