<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="utf-8">
    <title>Recuperar Contraseña</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css"
        integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="login.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <script type="text/javascript" src="login.js"></script>
</head>

<body>

    <div class="text-center password-container card">
        <div class="form-register">
            <form action="NewPass.php" method="get">
            <h1>Cambio de Contraseña</h1>
            <div class="form-register">
                    <input class="input" type="email" id="email" placeholder="Correo" name="email"
                    required autofocus>
                <input class="input" type="password" id="passwordActual" placeholder="Contraseña actual" name="passwordActual"
                    required autofocus>
                <input class="input" type="password" id="passwordNueva" placeholder="Contraseña nueva" name="passwordNueva"
                    required autofocus>
                <input class="input" type="password" id="password2" placeholder="Ingresela de nuevo" name="password2"
                    required autofocus>
            </div>
            <div>
                <input class=" btn btn-login " type="submit" value="Actualizar"></button>
            </div>
            </form>

        </div>
    </div>
</body>

