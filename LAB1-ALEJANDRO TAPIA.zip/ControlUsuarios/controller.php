<?php

include "DaoConexion.php";

class controller
{

    public function __construct()
    {
        //$DAO = new DaoConexion();

    }

    function validarCredenciales($user, $pass)
    {
        $DAO = new DaoConexion();
        $usuario = $DAO->getUser($user);
        $password = $DAO->getPass($user);

        if ($usuario == $user && $pass == $password) {
            return true;
        } else
            return false;
    }

    function NuevoUsuario()
    {
        $DAO = new DaoConexion();

        $nombre = $_GET["name"];
        $Apellido1 = $_GET["apellido1"];
        $Apellido2 = $_GET["apellido2"];
        $Identificacion = $_GET["identificacion"];
        $correo = $_GET["correo"];
        $contrasena = $_GET["password"];
        $telefono = $_GET["telefono"];
        $Nacimiento = $_GET["fecha"];

        $DAO->conectar();

        $DAO->NewUser($nombre, $Apellido1, $Apellido2, $Identificacion, $correo, $contrasena, $telefono, $Nacimiento);
    }


    function UpdatePass()
    {


        $DAO = new DaoConexion();

        $usuario = $_GET["email"];
        $oldPass = $_GET["passwordActual"];
        $newPass = $_GET["passwordNueva"];
        $confPass = $_GET["password2"];


        if ($newPass === $confPass) {

            if ($this->validarCredenciales($usuario, $oldPass)) {
                if ($this->validar_password($newPass, $error = '')) {
                    $DAO->UpdatePassword($usuario, $newPass);
                } else
                    echo '<script language="javascript">alert("'.$error.'");
                history.back();"</script>';
            } else {
                echo '<script language="javascript">alert("la contrasena actual es incorrecta");
                history.back();"</script>';
            }
        } else {
            echo '<script language="javascript">alert("La contrasenas deben de ser iguales");
            history.back();"</script>';
        }
    }
    function valid_email($str)
    {
        return (false !== filter_var($str, FILTER_VALIDATE_EMAIL));
    }

    function valid_email_Registro($correo)
    {
        $DAO = new DaoConexion;

        if (!$DAO->IfUser($correo)) {
            return true;
        } else
            return false;
    }

    function validar_password($password, &$error_password)
    {
        if (strlen($password) < 8) {
            $error_password = "El password debe tener al menos 6 caracteres";
            return false;
        }
        if (strlen($password) > 16) {
            $error_password = "El password no puede tener más de 16 caracteres";
            return false;
        }
        if (!preg_match('`[a-z]`', $password)) {
            $error_password = "El password debe tener al menos una letra minúscula";
            return false;
        }
        if (!preg_match('`[A-Z]`', $password)) {
            $error_password = "El password debe tener al menos una letra mayúscula";
            return false;
        }
        if (!preg_match('`[0-9]`', $password)) {
            $error_password = "El password debe tener al menos un caracter numérico";
            return false;
        }
        $error_password = "";
        return true;
    }
}
