
    <?php
    $correoU = $_GET["correo"];
    $passU = $_GET["password"];

    include 'controller.php';
    $controller = new controller;

    $error = '';

    if ($controller->valid_email_Registro($correoU)) {
        if ($controller->validar_password($passU, $error)) {
            $controller->NuevoUsuario();
        } else
            echo '<script language="javascript">alert("' . $error . '");
    history.back();
    </script>';
    } else    echo '<script language="javascript">alert("El correo ya es utilizado");
    history.back();
    </script>';
    ?>

