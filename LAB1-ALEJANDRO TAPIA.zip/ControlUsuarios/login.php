<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="utf-8">
    <title>Login</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css"
        integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="login.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <script type="text/javascript" src="login.js"></script>
</head>


<body>
     <?php   
        $email = $password ='';


    ?>
    <div class="barra">
        <button class=" btn btn-login cambio-pag " type="submit" onclick="location.href='register.php'">Registrarse</button>
        
    </div>
    <div class="text-center login-container card">
        <i class="material-icons md-48 ">account_circle</i>
        <div class="form-sigin">
        <form action="signin.php" method="get">
            <h1>Iniciar Sesión</h1>
            <div>
                <input class="input" type="email" id="email" placeholder="Ingrese su correo" name="correoUser" required
                    autofocus>
                <BR>
                <div>
                    <input class="input" type="password" id="password" placeholder="Ingrese su contraseña"
                        name="password" required autofocus>
                    <span class="input-group-btn-a">
                        <button class="btn btn-sm" type="button" onclick="ShowPass()">
                            <i class="material-icons md-12">remove_red_eye</i></button>
                    </span>

                </div>
            </div>
            <div>
                <input class=" btn btn-login " type="submit" value="Ingresar"></button>
            </div>
            <div>
                <a href="recover.php">¿Olvido su contraseña?</a>
            </div>
            <div>
                <a href="pass.php">Cambiar contraseña</a>
            </div>
            </form>

        </div>
    </div>

    <script src="login.js"></script>
    

</body>


