<?php

class DaoConexion
{

    private $conn;
    private $servername = "localhost";
    private $username = "root";
    private $password = '';
    private $db_name = 'lab1';
    private $DaoConexion;

    // Create connection

    public function __construct()
    {
        $this->conn = new mysqli($this->servername, $this->username, $this->password, $this->db_name);
    }
    // Check connection

    public function conectar()
    {
        $this->conn = new mysqli($this->servername, $this->username, $this->password, $this->db_name);
    }
    public function getConn()
    {
        return $this->conn;
    }

    public function desconectarse()
    {
        return $this->conn->close();
    }


    function getUser($correoUsuario)
    {

        $dao = new DaoConexion;
        $conn = $dao->getConn();
        $sql = "SELECT * FROM usuario  WHERE Correo = '$correoUsuario'";
        $result = $conn->query($sql);

        if ($result->num_rows) {
            $row = $result->fetch_assoc();
            return $row["Correo"];
        } else
            return  "No se encontro el usuario";
    }
    function IfUser($user){

        $dao = new DaoConexion;
        $conn = $dao->getConn();
        $sql = "SELECT * FROM usuario  WHERE Correo = '$user'"; 
        $result = $conn->query($sql);
        
        if ($result->num_rows>=1) {
            return true;
        } else
            return  false;
    }
    function getPass($user)
    {
        $dao = new DaoConexion;
        $conn = $dao->getConn();

        $sql = "SELECT * FROM usuario WHERE Correo = '$user'";
        $result = $conn->query($sql);

        if ($result->num_rows) {
            $row = $result->fetch_assoc();
            return $row["Contraseña"];
        } else
            return  "No se encontro el usuario";
    }


    function NewUser($nombre, $Apellido1, $Apellido2, $Identificacion, $correo, $contrasena, $telefono, $Nacimiento)
    {
        $dao = new DaoConexion;
        $conn = $dao->getConn();

        $sql = "INSERT INTO usuario(Nombre, Apellido1, Apellido2, Identificacion, Correo, Contraseña, Telefono,`Fecha de Nacimiento`) VALUES
        ('$nombre','$Apellido1','$Apellido2','$Identificacion','$correo','$contrasena','$telefono','$Nacimiento');";

        if ($conn->query($sql) === TRUE) {
            echo '<script language="javascript">alert("Se ingreso Correctamente");
            window.location.href="login.php";
            </script>';
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    }

    function UpdatePassword($user, $newpassword)
    {

        $dao = new DaoConexion;
        $conn = $dao->getConn();


        $sql = "UPDATE `usuario` SET `Contraseña`='$newpassword' WHERE `Correo` = '$user'";

        if ($conn->query($sql) === TRUE) {
            echo '<script language="javascript">alert("Cambio Exitoso");
            window.location.href="login.php"
            </script>';
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    }
}



 // function getUser($correoUsuario)
    // {

    // $dao= new DaoConexion;
    // $conn = $dao->getConn();
    // $sql = "SELECT * FROM usuario  WHERE Correo = '$correoUsuario";

    //     $result = $conn->query($sql);
    //     if ($result->num_rows > 0) {
    //         // output data of each row
    //         while ($row = $result->fetch_assoc()) {
    //             return $row["Nombre"];
    //         }
    //     } else {
    //         echo "No hay resultados";
    //     }
    // }
