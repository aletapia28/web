

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="utf-8">
    <title>Login</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css"
        integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="registrarse.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <script type="text/javascript" src="login.js"></script>
</head>


<body>
    <h1 class="titulo">Bienvenido</h1>
    <div class="center">

        <button class="button  gris" onclick="location.href='login.php'">Iniciar Sesion</button>
        <button class="button  nar " onclick="location.href='register.php'">Registrarse</button>


    </div>


</body>


