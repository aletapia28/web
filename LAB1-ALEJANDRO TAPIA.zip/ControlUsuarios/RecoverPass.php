<?php
echo '<script language="javascript">alert("Se envio un correo con las indicaciones");
      window.location.href="login.php";</script>';
?>